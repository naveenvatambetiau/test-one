package com.nab.eda.dm.recon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReconServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
