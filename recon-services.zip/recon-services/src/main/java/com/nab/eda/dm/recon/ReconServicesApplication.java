package com.nab.eda.dm.recon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReconServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReconServicesApplication.class, args);
	}

}
